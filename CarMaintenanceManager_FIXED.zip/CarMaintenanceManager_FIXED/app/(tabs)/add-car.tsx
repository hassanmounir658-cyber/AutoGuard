import { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, Alert } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCars } from '@/lib/cars';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import { ChevronRight } from 'lucide-react-native';

export default function AddCarScreen() {
  const { addCar } = useCars();
  const insets = useSafeAreaInsets();
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [odometer, setOdometer] = useState('');
  const [nickname, setNickname] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    if (!make.trim() || !model.trim() || !year.trim()) {
      setError('يرجى إدخال الماركة والموديل وسنة الصنع');
      return;
    }
    const yearNum = parseInt(year, 10);
    if (isNaN(yearNum) || yearNum < 1900 || yearNum > 2100) {
      setError('سنة الصنع غير صحيحة');
      return;
    }
    const odoNum = parseInt(odometer, 10) || 0;
    if (odoNum < 0) {
      setError('قراءة العداد غير صحيحة');
      return;
    }

    setLoading(true);
    setError(null);
    const { error } = await addCar({
      make: make.trim(),
      model: model.trim(),
      year: yearNum,
      odometer: odoNum,
      nickname: nickname.trim() || null,
    });
    setLoading(false);
    if (error) {
      setError(error);
      return;
    }
    router.back();
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronRight size={24} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إضافة سيارة</Text>
        <View style={styles.backButton} />
      </View>

      <ScrollView contentContainerStyle={[styles.form, { paddingBottom: insets.bottom + 100 }]} keyboardShouldPersistTaps="handled">
        {error && (
          <View style={styles.errorBox}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        <Text style={styles.label}>الماركة *</Text>
        <TextInput
          style={styles.input}
          value={make}
          onChangeText={setMake}
          placeholder="مثال: Toyota"
          placeholderTextColor={colors.neutral[400]}
          textAlign="right"
        />

        <Text style={styles.label}>الموديل *</Text>
        <TextInput
          style={styles.input}
          value={model}
          onChangeText={setModel}
          placeholder="مثال: Camry"
          placeholderTextColor={colors.neutral[400]}
          textAlign="right"
        />

        <Text style={styles.label}>سنة الصنع *</Text>
        <TextInput
          style={styles.input}
          value={year}
          onChangeText={setYear}
          placeholder="مثال: 2020"
          placeholderTextColor={colors.neutral[400]}
          keyboardType="numeric"
          maxLength={4}
          textAlign="right"
        />

        <Text style={styles.label}>قراءة العداد الحالية (كم)</Text>
        <TextInput
          style={styles.input}
          value={odometer}
          onChangeText={setOdometer}
          placeholder="مثال: 50000"
          placeholderTextColor={colors.neutral[400]}
          keyboardType="numeric"
          textAlign="right"
        />

        <Text style={styles.label}>اسم مألوف (اختياري)</Text>
        <TextInput
          style={styles.input}
          value={nickname}
          onChangeText={setNickname}
          placeholder="مثال: سيارة العمل"
          placeholderTextColor={colors.neutral[400]}
          textAlign="right"
        />

        <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={loading}>
          {loading ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.saveButtonText}>حفظ السيارة</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xxl,
    color: colors.text,
  },
  form: {
    paddingHorizontal: spacing.lg,
  },
  errorBox: {
    backgroundColor: colors.error[50],
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.error[500],
  },
  errorText: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.error[600],
    textAlign: 'center',
  },
  label: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.sm,
    color: colors.text,
    marginBottom: spacing.xs,
    textAlign: 'right',
  },
  input: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    textAlign: 'right',
  },
  saveButton: {
    backgroundColor: colors.primary[600],
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  saveButtonText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.lg,
    color: colors.white,
  },
});
