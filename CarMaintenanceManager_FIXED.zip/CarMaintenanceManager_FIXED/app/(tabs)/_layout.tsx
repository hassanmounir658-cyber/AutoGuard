import { Tabs } from 'expo-router';
import { Car, Wrench, MapPin, LifeBuoy, Settings } from 'lucide-react-native';
import { colors, fontWeight } from '@/lib/theme';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary[600],
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: {
          fontFamily: fontWeight.regular,
          fontSize: 11,
        },
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'سياراتي',
          tabBarIcon: ({ size, color }) => <Car size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="maintenance"
        options={{
          title: 'الصيانة',
          tabBarIcon: ({ size, color }) => <Wrench size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="mileage"
        options={{
          title: 'المسافة',
          tabBarIcon: ({ size, color }) => <MapPin size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="assistance"
        options={{
          title: 'المساعدة',
          tabBarIcon: ({ size, color }) => <LifeBuoy size={size} color={color} strokeWidth={2} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'الإعدادات',
          tabBarIcon: ({ size, color }) => <Settings size={size} color={color} strokeWidth={2} />,
        }}
      />
    </Tabs>
  );
}
