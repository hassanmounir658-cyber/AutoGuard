import { useState, useEffect, useRef, useCallback } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { useCars } from '@/lib/cars';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import { MapPin, Play, Square, Navigation, Car as CarIcon } from 'lucide-react-native';

export default function MileageScreen() {
  const { cars, selectedCar, selectedCarId, selectCar, updateCar } = useCars();
  const insets = useSafeAreaInsets();
  const [tracking, setTracking] = useState(false);
  const [distance, setDistance] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [speed, setSpeed] = useState(0);
  const [locationReady, setLocationReady] = useState(false);
  const locationSubscription = useRef<Location.LocationSubscription | null>(null);
  const lastLocationRef = useRef<Location.LocationObject | null>(null);
  const distanceRef = useRef(0);
  const selectedCarRef = useRef(selectedCar);
  const trackingRef = useRef(false);

  useEffect(() => { selectedCarRef.current = selectedCar; }, [selectedCar]);
  useEffect(() => { trackingRef.current = tracking; }, [tracking]);

  useEffect(() => {
    return () => {
      locationSubscription.current?.remove();
      locationSubscription.current = null;
    };
  }, []);

  const calculateDistance = (a: Location.LocationObject, b: Location.LocationObject) => {
    const R = 6371;
    const dLat = ((b.coords.latitude - a.coords.latitude) * Math.PI) / 180;
    const dLon = ((b.coords.longitude - a.coords.longitude) * Math.PI) / 180;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.coords.latitude * Math.PI / 180) * Math.cos(b.coords.latitude * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  };

  const startTracking = useCallback(async () => {
    const car = selectedCarRef.current;
    if (!car) { setError('اختر سيارة أولاً'); return; }
    setError(null);

    const services = await Location.hasServicesEnabledAsync();
    if (!services) { setError('فعّل خدمة الموقع (GPS) في الهاتف ثم حاول مرة أخرى.'); return; }

    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') { setError('يلزم السماح بالموقع أثناء استخدام التطبيق لتتبع المسافة.'); return; }

    try {
      const initial = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      lastLocationRef.current = initial;
      distanceRef.current = 0;
      setDistance(0);
      setSpeed(0);
      setLocationReady(true);

      locationSubscription.current = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 2000, distanceInterval: 5 },
        (location) => {
          if (!trackingRef.current) return;
          const previous = lastLocationRef.current;
          const current = location.coords;
          if (previous) {
            const d = calculateDistance(previous, location);
            const accuracy = current.accuracy ?? 999;
            // Ignore GPS jumps/noise and tiny stationary movements.
            if (accuracy <= 50 && d >= 0.005 && d <= 1.0) {
              distanceRef.current += d;
              setDistance(distanceRef.current);
            }
          }
          lastLocationRef.current = location;
          setSpeed(current.speed && current.speed > 0 ? current.speed * 3.6 : 0);
        }
      );
      setTracking(true);
    } catch {
      setError('فشل بدء تتبع GPS. حاول مرة أخرى.');
      locationSubscription.current?.remove();
      locationSubscription.current = null;
    }
  }, []);

  const stopTracking = useCallback(async () => {
    locationSubscription.current?.remove();
    locationSubscription.current = null;
    setTracking(false);
    setSpeed(0);

    const car = selectedCarRef.current;
    const traveled = distanceRef.current;
    if (car && traveled >= 0.01) {
      const newOdo = Math.round((car.odometer + traveled) * 10) / 10;
      const result = await updateCar(car.id, { odometer: newOdo });
      if (result.error) setError('تم إيقاف التتبع لكن تعذر حفظ العداد.');
    }
    distanceRef.current = 0;
    lastLocationRef.current = null;
  }, [updateCar]);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}><Text style={styles.headerTitle}>تتبع المسافة</Text></View>
      <View style={styles.content}>
        {error && <View style={styles.errorBox}><Text style={styles.errorText}>{error}</Text></View>}
        {selectedCar ? <View style={styles.carInfoCard}>
          <CarIcon size={20} color={colors.primary[600]} />
          <Text style={styles.carInfoText}>{selectedCar.nickname || `${selectedCar.make} ${selectedCar.model}`}</Text>
          <Text style={styles.carOdoText}>{selectedCar.odometer.toLocaleString('en-US')} كم</Text>
        </View> : <View style={styles.carInfoCard}><Text style={styles.carInfoText}>لا توجد سيارة محددة</Text></View>}

        <View style={styles.trackingCard}>
          <View style={styles.trackingIconContainer}><MapPin size={48} color={tracking ? colors.primary[600] : colors.neutral[300]} strokeWidth={1.5} />{tracking && <View style={styles.pulseRing} />}</View>
          <Text style={styles.distanceValue}>{distance.toFixed(2)}</Text>
          <Text style={styles.distanceUnit}>كيلومتر في هذه الرحلة</Text>
          {tracking && <View style={styles.speedBadge}><Navigation size={14} color={colors.primary[700]} /><Text style={styles.speedText}>{Math.round(speed)} كم/س</Text></View>}
        </View>

        <View style={styles.statusRow}><View style={[styles.statusDot, { backgroundColor: tracking ? colors.success[500] : colors.neutral[300] }]} /><Text style={styles.statusText}>{tracking ? 'التتبع نشط' : 'التتبع متوقف'}</Text></View>
        <TouchableOpacity style={[styles.trackButton, tracking && styles.stopButton]} onPress={tracking ? stopTracking : startTracking} disabled={!selectedCar}>
          {tracking ? <><Square size={22} color={colors.white} /><Text style={styles.trackButtonText}>إيقاف وحفظ المسافة</Text></> : <><Play size={22} color={colors.white} /><Text style={styles.trackButtonText}>بدء التتبع</Text></>}
        </TouchableOpacity>
        {locationReady && <Text style={styles.hint}>عند الإيقاف تُضاف المسافة المقطوعة تلقائيًا إلى عداد السيارة.</Text>}
        {Platform.OS === 'web' && <Text style={styles.webNote}>تتبع GPS الحقيقي يعمل على تطبيق Android المثبت، وليس كصفحة ويب.</Text>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  headerTitle: { fontFamily: fontWeight.bold, fontSize: fontSize.xxxl, color: colors.text },
  content: { flex: 1, paddingHorizontal: spacing.lg, paddingTop: spacing.sm },
  errorBox: { backgroundColor: colors.error[50], borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.error[500] },
  errorText: { fontFamily: fontWeight.regular, fontSize: fontSize.sm, color: colors.error[600], textAlign: 'center' },
  carInfoCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.lg, gap: spacing.sm },
  carInfoText: { fontFamily: fontWeight.medium, fontSize: fontSize.md, color: colors.text, flex: 1 },
  carOdoText: { fontFamily: fontWeight.bold, fontSize: fontSize.md, color: colors.primary[700] },
  trackingCard: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl, alignItems: 'center', marginBottom: spacing.lg },
  trackingIconContainer: { width: 80, height: 80, borderRadius: radius.round, backgroundColor: colors.primary[50], justifyContent: 'center', alignItems: 'center', marginBottom: spacing.lg },
  pulseRing: { position: 'absolute', width: 80, height: 80, borderRadius: radius.round, borderWidth: 2, borderColor: colors.primary[400], opacity: 0.5 },
  distanceValue: { fontFamily: fontWeight.bold, fontSize: 48, color: colors.text },
  distanceUnit: { fontFamily: fontWeight.regular, fontSize: fontSize.lg, color: colors.textSecondary, marginTop: spacing.xs },
  speedBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.primary[50], paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.round, marginTop: spacing.md, gap: spacing.xs },
  speedText: { fontFamily: fontWeight.medium, fontSize: fontSize.sm, color: colors.primary[700] },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm, marginBottom: spacing.lg },
  statusDot: { width: 10, height: 10, borderRadius: radius.round },
  statusText: { fontFamily: fontWeight.medium, fontSize: fontSize.md, color: colors.textSecondary },
  trackButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary[600], borderRadius: radius.lg, paddingVertical: spacing.lg, gap: spacing.sm },
  stopButton: { backgroundColor: colors.error[500] },
  trackButtonText: { fontFamily: fontWeight.bold, fontSize: fontSize.lg, color: colors.white },
  hint: { fontFamily: fontWeight.regular, fontSize: fontSize.sm, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.md, lineHeight: 20 },
  webNote: { fontFamily: fontWeight.regular, fontSize: fontSize.xs, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.lg },
});
