import { useEffect, useState, useCallback } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, RefreshControl, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCars } from '@/lib/cars';
import { useAuth } from '@/lib/auth';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import { Car as CarIcon, Plus, ChevronLeft, Trash2 } from 'lucide-react-native';
import { Car } from '@/lib/types';

export default function CarsScreen() {
  const { cars, selectedCarId, selectCar, fetchCars, loading, deleteCar } = useCars();
  const insets = useSafeAreaInsets();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchCars();
  }, [fetchCars]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchCars();
    setRefreshing(false);
  }, [fetchCars]);

  const handleCarPress = (car: Car) => {
    selectCar(car.id);
    router.push('/(tabs)/maintenance');
  };

  const handleDelete = async (car: Car) => {
    await deleteCar(car.id);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>سياراتي</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => router.push('/(tabs)/add-car')}>
          <Plus size={24} color={colors.white} strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {loading && cars.length === 0 ? (
        <View style={styles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary[600]} />
        </View>
      ) : (
        <FlatList
          data={cars}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 80 }]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <CarIcon size={64} color={colors.neutral[300]} strokeWidth={1.5} />
              <Text style={styles.emptyTitle}>لا توجد سيارات</Text>
              <Text style={styles.emptySubtitle}>أضف سيارتك الأولى للبدء</Text>
              <TouchableOpacity style={styles.emptyButton} onPress={() => router.push('/(tabs)/add-car')}>
                <Plus size={20} color={colors.white} strokeWidth={2} />
                <Text style={styles.emptyButtonText}>إضافة سيارة</Text>
              </TouchableOpacity>
            </View>
          }
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.carCard,
                selectedCarId === item.id && styles.carCardSelected,
              ]}
              onPress={() => handleCarPress(item)}
              activeOpacity={0.7}
            >
              <View style={styles.carIconBox}>
                <CarIcon size={32} color={colors.primary[600]} strokeWidth={2} />
              </View>
              <View style={styles.carInfo}>
                <Text style={styles.carName}>
                  {item.nickname || `${item.make} ${item.model}`}
                </Text>
                <Text style={styles.carDetails}>
                  {item.make} • {item.model} • {item.year}
                </Text>
                <View style={styles.odometerBadge}>
                  <Text style={styles.odometerText}>{item.odometer.toLocaleString('en-US')} كم</Text>
                </View>
              </View>
              <View style={styles.carActions}>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => handleDelete(item)}
                >
                  <Trash2 size={18} color={colors.error[500]} strokeWidth={2} />
                </TouchableOpacity>
                <ChevronLeft size={24} color={colors.neutral[400]} strokeWidth={2} />
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xxxl,
    color: colors.text,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: radius.round,
    backgroundColor: colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
  },
  list: {
    paddingHorizontal: spacing.lg,
  },
  carCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  carCardSelected: {
    borderColor: colors.primary[500],
    backgroundColor: colors.primary[50],
  },
  carIconBox: {
    width: 56,
    height: 56,
    borderRadius: radius.md,
    backgroundColor: colors.primary[50],
    justifyContent: 'center',
    alignItems: 'center',
  },
  carInfo: {
    flex: 1,
    marginRight: spacing.md,
    marginLeft: spacing.md,
  },
  carName: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.lg,
    color: colors.text,
  },
  carDetails: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  odometerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  odometerText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.xs,
    color: colors.primary[700],
    backgroundColor: colors.primary[50],
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.sm,
    overflow: 'hidden',
  },
  carActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  deleteButton: {
    padding: spacing.xs,
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: spacing.xxl * 2,
  },
  emptyTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xl,
    color: colors.text,
    marginTop: spacing.md,
  },
  emptySubtitle: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.md,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    marginBottom: spacing.lg,
  },
  emptyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary[600],
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    gap: spacing.sm,
  },
  emptyButtonText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.white,
  },
});
