import { useState, useEffect, useCallback } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/lib/auth';
import { useCars } from '@/lib/cars';
import { supabase } from '@/lib/supabase';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import {
  Settings as SettingsIcon,
  LogOut,
  Bell,
  User,
  Car as CarIcon,
  Info,
  ChevronLeft,
} from 'lucide-react-native';
import * as Notifications from 'expo-notifications';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const { cars, fetchCars } = useCars();
  const insets = useSafeAreaInsets();
  const [notifStatus, setNotifStatus] = useState<string | null>(null);
  const [checkingNotifs, setCheckingNotifs] = useState(false);

  useEffect(() => {
    fetchCars();
  }, [fetchCars]);

  useEffect(() => {
    (async () => {
      const { status } = await Notifications.getPermissionsAsync();
      setNotifStatus(status);
    })();
  }, []);

  const requestNotifPermission = useCallback(async () => {
    setCheckingNotifs(true);
    const { status } = await Notifications.requestPermissionsAsync();
    setNotifStatus(status);
    setCheckingNotifs(false);
    if (status === 'granted') {
      Alert.alert('تم', 'سيتم إرسال إشعارات الصيانة');
    } else {
      Alert.alert('تنبيه', 'يلزم إذن الإشعارات لتلقي تذكيرات الصيانة');
    }
  }, []);

  const handleSignOut = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تسجيل الخروج', style: 'destructive', onPress: () => signOut() },
      ]
    );
  };

  return (
    <ScrollView style={[styles.container, { paddingTop: insets.top }]} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الإعدادات</Text>
      </View>

      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <User size={32} color={colors.white} strokeWidth={2} />
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.profileEmail}>{user?.email || 'مستخدم'}</Text>
          <Text style={styles.profileSubtext}>{cars.length} سيارة مسجلة</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الإشعارات</Text>
        <TouchableOpacity style={styles.row} onPress={requestNotifPermission} disabled={checkingNotifs}>
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Bell size={20} color={colors.primary[600]} strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.rowTitle}>إشعارات الصيانة</Text>
              <Text style={styles.rowSubtitle}>
                {notifStatus === 'granted' ? 'مفعّلة' : 'غير مفعّلة - اضغط للتفعيل'}
              </Text>
            </View>
          </View>
          {checkingNotifs ? (
            <ActivityIndicator size="small" color={colors.primary[600]} />
          ) : (
            <View style={[styles.statusDot, { backgroundColor: notifStatus === 'granted' ? colors.success[500] : colors.neutral[300] }]} />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الحساب</Text>
        <TouchableOpacity style={styles.row} onPress={handleSignOut}>
          <View style={styles.rowLeft}>
            <View style={[styles.rowIcon, { backgroundColor: colors.error[50] }]}>
              <LogOut size={20} color={colors.error[500]} strokeWidth={2} />
            </View>
            <Text style={[styles.rowTitle, { color: colors.error[600] }]}>تسجيل الخروج</Text>
          </View>
          <ChevronLeft size={20} color={colors.neutral[300]} strokeWidth={2} />
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>عن التطبيق</Text>
        <View style={styles.aboutCard}>
          <Info size={20} color={colors.textSecondary} strokeWidth={2} />
          <Text style={styles.aboutText}>صيانة سياراتي - إصدار 1.0</Text>
        </View>
        <View style={styles.aboutCard}>
          <CarIcon size={20} color={colors.textSecondary} strokeWidth={2} />
          <Text style={styles.aboutText}>تطبيق إدارة صيانة السيارات</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xxxl,
    color: colors.text,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    gap: spacing.md,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: radius.round,
    backgroundColor: colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    flex: 1,
  },
  profileEmail: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.text,
  },
  profileSubtext: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  section: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flex: 1,
  },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.primary[50],
    justifyContent: 'center',
    alignItems: 'center',
  },
  rowTitle: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.md,
    color: colors.text,
  },
  rowSubtitle: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    marginTop: 2,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: radius.round,
  },
  aboutCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    gap: spacing.md,
  },
  aboutText: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
});
