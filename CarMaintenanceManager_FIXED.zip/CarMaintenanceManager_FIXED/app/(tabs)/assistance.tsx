import { useState, useCallback } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ActivityIndicator, Linking, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import { LifeBuoy, MapPin, Phone, Navigation, Wrench, Truck, Search, ExternalLink, AlertCircle } from 'lucide-react-native';

interface NearbyPlace {
  id: string;
  name: string;
  category: 'mechanic' | 'service_center' | 'towing';
  distance: number | null;
  phone: string | null;
  address: string | null;
  lat: number;
  lon: number;
}

const OVERPASS_URL = 'https://overpass-api.de/api/interpreter';

export default function AssistanceScreen() {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [places, setPlaces] = useState<NearbyPlace[]>([]);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const findAssistance = useCallback(async () => {
    setError(null);
    setLoading(true);
    setHasSearched(true);
    setPlaces([]);

    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setError('اسمح للتطبيق بالوصول إلى موقعك حتى نبحث عن الخدمات القريبة.');
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const { latitude, longitude } = loc.coords;
      setLocation({ lat: latitude, lng: longitude });

      const query = `[out:json][timeout:20];(nwr(around:10000,${latitude},${longitude})[shop=car_repair];nwr(around:10000,${latitude},${longitude})[amenity=car_repair];nwr(around:10000,${latitude},${longitude})[craft=car_repair];nwr(around:10000,${latitude},${longitude})[shop=tyres];nwr(around:10000,${latitude},${longitude})[service=vehicle_repair];nwr(around:10000,${latitude},${longitude})[amenity=vehicle_inspection];nwr(around:10000,${latitude},${longitude})[amenity=vehicle_rental];nwr(around:10000,${latitude},${longitude})[shop=car];nwr(around:10000,${latitude},${longitude})[amenity=taxi];);out center tags;`;

      const response = await fetch(OVERPASS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain', 'Accept': 'application/json' },
        body: query,
      });

      if (!response.ok) throw new Error('overpass');
      const data = await response.json();
      const raw = Array.isArray(data.elements) ? data.elements : [];

      const mapped: NearbyPlace[] = raw.map((item: any, index: number) => {
        const tags = item.tags || {};
        const lat = item.lat ?? item.center?.lat;
        const lon = item.lon ?? item.center?.lon;
        const name = tags.name || tags['name:ar'] || 'خدمة سيارات قريبة';
        const isTowing = /tow|towing|recovery|سطحة|ونش/i.test(`${name} ${tags.description || ''} ${tags.service || ''}`);
        const isTire = tags.shop === 'tyres' || /tire|tyre|إطارات/i.test(name);
        const category = isTowing ? 'towing' : isTire ? 'service_center' : 'mechanic';
        return {
          id: `${item.type}-${item.id}-${index}`,
          name,
          category,
          distance: typeof lat === 'number' && typeof lon === 'number' ? calculateDistance(latitude, longitude, lat, lon) : null,
          phone: tags.phone || tags['contact:phone'] || null,
          address: [tags['addr:street'], tags['addr:housenumber'], tags['addr:city']].filter(Boolean).join(' ') || tags['addr:full'] || null,
          lat,
          lon,
        };
      }).filter((p: NearbyPlace) => Number.isFinite(p.lat) && Number.isFinite(p.lon));

      const unique = Array.from(new Map(mapped.map((p) => [`${p.name}|${p.lat.toFixed(5)}|${p.lon.toFixed(5)}`, p])).values());
      unique.sort((a, b) => (a.distance ?? 999) - (b.distance ?? 999));
      setPlaces(unique.slice(0, 30));

      if (unique.length === 0) {
        setError('لم نجد بيانات لخدمات قريبة في قاعدة الخرائط. يمكنك فتح خرائط Google والبحث مباشرة.');
      }
    } catch {
      setError('تعذر تحميل الخدمات القريبة الآن. يمكنك فتح خرائط Google والبحث مباشرة.');
    } finally {
      setLoading(false);
    }
  }, []);

  const openDirections = (place: NearbyPlace) => {
    if (!location) return;
    const url = `https://www.google.com/maps/dir/?api=1&origin=${location.lat},${location.lng}&destination=${place.lat},${place.lon}&travelmode=driving`;
    Linking.openURL(url);
  };

  const openPlaceOnMaps = (place: NearbyPlace) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${place.lat},${place.lon}`;
    Linking.openURL(url);
  };

  const searchOnMaps = (query: string) => {
    Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`);
  };

  const categoryConfig = {
    mechanic: { Icon: Wrench, label: 'ميكانيكي', color: colors.primary[600], bg: colors.primary[50] },
    service_center: { Icon: LifeBuoy, label: 'مركز خدمة', color: colors.accent[600], bg: colors.accent[50] },
    towing: { Icon: Truck, label: 'سطحة', color: colors.error[500], bg: colors.error[50] },
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}> 
      <View style={styles.header}><Text style={styles.headerTitle}>المساعدة على الطريق</Text></View>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 80 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.heroCard}>
          <View style={styles.heroIcon}><LifeBuoy size={40} color={colors.white} strokeWidth={1.5} /></View>
          <Text style={styles.heroTitle}>هل تحتاج مساعدة؟</Text>
          <Text style={styles.heroSubtitle}>نحدد موقعك عند الطلب ونبحث عن ميكانيكيين ومراكز خدمة وورش قريبة.</Text>
          <TouchableOpacity style={styles.searchButton} onPress={findAssistance} disabled={loading}>
            {loading ? <ActivityIndicator color={colors.white} /> : <><Search size={20} color={colors.white} /><Text style={styles.searchButtonText}>البحث عن مساعدة</Text></>}
          </TouchableOpacity>
        </View>

        {error && <View style={styles.errorBox}><AlertCircle size={20} color={colors.error[600]} /><Text style={styles.errorText}>{error}</Text></View>}
        {location && <View style={styles.locationInfo}><MapPin size={16} color={colors.primary[600]} /><Text style={styles.locationText}>تم تحديد موقعك الحالي</Text></View>}

        {places.length > 0 && <View style={styles.placesList}>
          <Text style={styles.sectionTitle}>الخدمات القريبة ({places.length})</Text>
          {places.map((place) => {
            const cfg = categoryConfig[place.category];
            return <View key={place.id} style={styles.placeCard}>
              <View style={[styles.placeIconBox, { backgroundColor: cfg.bg }]}><cfg.Icon size={22} color={cfg.color} /></View>
              <View style={styles.placeInfo}>
                <Text style={styles.placeName} numberOfLines={2}>{place.name}</Text>
                <View style={styles.placeCategoryRow}>
                  <View style={[styles.categoryBadge, { backgroundColor: cfg.bg }]}><Text style={[styles.categoryText, { color: cfg.color }]}>{cfg.label}</Text></View>
                  {place.distance != null && <Text style={styles.distanceText}>{place.distance < 1 ? `${Math.round(place.distance * 1000)} م` : `${place.distance.toFixed(1)} كم`}</Text>}
                </View>
                {place.address && <Text style={styles.placeAddress} numberOfLines={2}>{place.address}</Text>}
                <View style={styles.placeActions}>
                  {place.phone && <TouchableOpacity style={styles.actionButton} onPress={() => Linking.openURL(`tel:${place.phone}`)}><Phone size={14} color={colors.primary[600]} /><Text style={styles.actionText}>اتصال</Text></TouchableOpacity>}
                  <TouchableOpacity style={styles.actionButton} onPress={() => openPlaceOnMaps(place)}><ExternalLink size={14} color={colors.primary[600]} /><Text style={styles.actionText}>الخريطة</Text></TouchableOpacity>
                  <TouchableOpacity style={[styles.actionButton, styles.directionsButton]} onPress={() => openDirections(place)}><Navigation size={14} color={colors.white} /><Text style={styles.directionsText}>الاتجاهات</Text></TouchableOpacity>
                </View>
              </View>
            </View>;
          })}
        </View>}

        {hasSearched && !loading && <TouchableOpacity style={styles.manualSearchButton} onPress={() => searchOnMaps('ميكانيكي سيارات بالقرب مني')}><ExternalLink size={16} color={colors.primary[600]} /><Text style={styles.manualSearchText}>البحث في خرائط Google</Text></TouchableOpacity>}
        <View style={styles.disclaimerCard}><Text style={styles.disclaimerTitle}>ملاحظة</Text><Text style={styles.disclaimerText}>الموقع لا يتم استخدامه إلا عند طلب المساعدة. أرقام الهواتف تظهر فقط عندما تكون منشورة في بيانات المكان.</Text></View>
      </ScrollView>
    </View>
  );
}

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  headerTitle: { fontFamily: fontWeight.bold, fontSize: fontSize.xxxl, color: colors.text },
  content: { paddingHorizontal: spacing.lg },
  heroCard: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl, alignItems: 'center', marginBottom: spacing.lg },
  heroIcon: { width: 72, height: 72, borderRadius: radius.round, backgroundColor: colors.primary[600], justifyContent: 'center', alignItems: 'center', marginBottom: spacing.md },
  heroTitle: { fontFamily: fontWeight.bold, fontSize: fontSize.xxl, color: colors.text, textAlign: 'center' },
  heroSubtitle: { fontFamily: fontWeight.regular, fontSize: fontSize.md, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xs, marginBottom: spacing.lg, lineHeight: 24 },
  searchButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.primary[600], borderRadius: radius.lg, paddingVertical: spacing.md, paddingHorizontal: spacing.xl, gap: spacing.sm },
  searchButtonText: { fontFamily: fontWeight.bold, fontSize: fontSize.lg, color: colors.white },
  errorBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.error[50], borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.error[500], gap: spacing.sm },
  errorText: { fontFamily: fontWeight.regular, fontSize: fontSize.sm, color: colors.error[600], flex: 1 },
  locationInfo: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.primary[50], borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, gap: spacing.xs },
  locationText: { fontFamily: fontWeight.regular, fontSize: fontSize.sm, color: colors.primary[700] },
  placesList: { marginBottom: spacing.md },
  sectionTitle: { fontFamily: fontWeight.bold, fontSize: fontSize.lg, color: colors.text, marginBottom: spacing.md },
  placeCard: { flexDirection: 'row', backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md },
  placeIconBox: { width: 44, height: 44, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center' },
  placeInfo: { flex: 1, marginLeft: spacing.sm },
  placeName: { fontFamily: fontWeight.bold, fontSize: fontSize.md, color: colors.text },
  placeCategoryRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.xs },
  categoryBadge: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  categoryText: { fontFamily: fontWeight.medium, fontSize: fontSize.xs },
  distanceText: { fontFamily: fontWeight.medium, fontSize: fontSize.xs, color: colors.textSecondary },
  placeAddress: { fontFamily: fontWeight.regular, fontSize: fontSize.xs, color: colors.textSecondary, marginTop: spacing.xs },
  placeActions: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.sm },
  actionButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.primary[50], paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.sm, gap: 4 },
  actionText: { fontFamily: fontWeight.medium, fontSize: fontSize.xs, color: colors.primary[700] },
  directionsButton: { backgroundColor: colors.primary[600] },
  directionsText: { fontFamily: fontWeight.medium, fontSize: fontSize.xs, color: colors.white },
  manualSearchButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary[50], paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderRadius: radius.md, gap: spacing.sm, marginBottom: spacing.md },
  manualSearchText: { fontFamily: fontWeight.bold, fontSize: fontSize.md, color: colors.primary[700] },
  disclaimerCard: { backgroundColor: colors.neutral[100], borderRadius: radius.md, padding: spacing.md, marginTop: spacing.md },
  disclaimerTitle: { fontFamily: fontWeight.bold, fontSize: fontSize.sm, color: colors.text, marginBottom: spacing.xs },
  disclaimerText: { fontFamily: fontWeight.regular, fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 18 },
});
