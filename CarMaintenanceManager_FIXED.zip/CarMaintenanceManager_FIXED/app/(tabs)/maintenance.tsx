import { useEffect, useState, useCallback } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, RefreshControl, ActivityIndicator, Modal, TextInput, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCars } from '@/lib/cars';
import { supabase } from '@/lib/supabase';
import { colors, spacing, radius, fontSize, fontWeight } from '@/lib/theme';
import {
  Wrench,
  Plus,
  ChevronDown,
  AlertCircle,
  Clock,
  CheckCircle,
  Droplet,
  Filter,
  Wind,
  Sparkles,
  Disc,
  Settings as SettingsIcon,
  Trash2,
  X,
} from 'lucide-react-native';
import {
  MaintenanceItem,
  MaintenanceCategory,
  MAINTENANCE_CATEGORIES,
  getNextMaintenanceOdometer,
  getRemainingKm,
  getMaintenanceStatus,
} from '@/lib/types';

const CATEGORY_ICONS: Record<MaintenanceCategory, typeof Wrench> = {
  engine_oil: Droplet,
  transmission_oil: Droplet,
  oil_filter: Filter,
  air_filter: Wind,
  cabin_filter: Wind,
  spark_plugs: Sparkles,
  tires: Disc,
  custom: Wrench,
};

export default function MaintenanceScreen() {
  const { cars, selectedCarId, selectedCar, fetchCars, selectCar } = useCars();
  const insets = useSafeAreaInsets();
  const [items, setItems] = useState<MaintenanceItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showCarPicker, setShowCarPicker] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  const fetchItems = useCallback(async () => {
    if (!selectedCarId) {
      setItems([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('maintenance_items')
      .select('*')
      .eq('car_id', selectedCarId)
      .order('category', { ascending: true });
    setLoading(false);
    if (!error && data) {
      setItems(data);
    }
  }, [selectedCarId]);

  useEffect(() => {
    fetchCars();
  }, [fetchCars]);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([fetchCars(), fetchItems()]);
    setRefreshing(false);
  }, [fetchCars, fetchItems]);

  const handleAddItem = async (item: Omit<MaintenanceItem, 'id' | 'car_id' | 'created_at' | 'updated_at'>) => {
    if (!selectedCarId) return;
    const { data, error } = await supabase
      .from('maintenance_items')
      .insert({ ...item, car_id: selectedCarId })
      .select()
      .single();
    if (!error && data) {
      setItems(prev => [...prev, data]);
    }
    setShowAddModal(false);
  };

  const handleDeleteItem = async (item: MaintenanceItem) => {
    const { error } = await supabase.from('maintenance_items').delete().eq('id', item.id);
    if (!error) {
      setItems(prev => prev.filter(i => i.id !== item.id));
    }
  };

  const handleUpdateOdometer = async (newOdo: number) => {
    if (!selectedCar) return;
    const { supabase: _ } = { supabase };
    const { error } = await supabase
      .from('cars')
      .update({ odometer: newOdo, updated_at: new Date().toISOString() })
      .eq('id', selectedCar.id);
    if (!error) {
      await fetchCars();
    }
  };

  if (cars.length === 0) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>الصيانة</Text>
        </View>
        <View style={styles.emptyState}>
          <Wrench size={64} color={colors.neutral[300]} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>لا توجد سيارات</Text>
          <Text style={styles.emptySubtitle}>أضف سيارة أولاً لتتبع صيانتها</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الصيانة</Text>
        <TouchableOpacity
          style={styles.carSelector}
          onPress={() => setShowCarPicker(true)}
        >
          <Text style={styles.carSelectorText} numberOfLines={1}>
            {selectedCar ? (selectedCar.nickname || `${selectedCar.make} ${selectedCar.model}`) : 'اختر سيارة'}
          </Text>
          <ChevronDown size={18} color={colors.primary[600]} strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {selectedCar && (
        <View style={styles.odometerCard}>
          <View style={styles.odometerLeft}>
            <Text style={styles.odometerLabel}>قراءة العداد الحالية</Text>
            <Text style={styles.odometerValue}>{selectedCar.odometer.toLocaleString('en-US')} كم</Text>
          </View>
          <UpdateOdometerButton currentOdo={selectedCar.odometer} onUpdate={handleUpdateOdometer} />
        </View>
      )}

      {loading && items.length === 0 ? (
        <View style={styles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary[600]} />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 80 }]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Wrench size={48} color={colors.neutral[300]} strokeWidth={1.5} />
              <Text style={styles.emptyTitle}>لا توجد عناصر صيانة</Text>
              <Text style={styles.emptySubtitle}>أضف عناصر الصيانة لتتبع مواعيدها</Text>
            </View>
          }
          ListHeaderComponent={
            items.length > 0 ? (
              <TouchableOpacity style={styles.addItemButton} onPress={() => setShowAddModal(true)}>
                <Plus size={20} color={colors.primary[600]} strokeWidth={2} />
                <Text style={styles.addItemText}>إضافة عنصر صيانة</Text>
              </TouchableOpacity>
            ) : undefined
          }
          renderItem={({ item }) => {
            const Icon = CATEGORY_ICONS[item.category] || Wrench;
            const nextOdo = getNextMaintenanceOdometer(item);
            const remaining = getRemainingKm(item, selectedCar?.odometer ?? 0);
            const status = getMaintenanceStatus(item, selectedCar?.odometer ?? 0);
            const statusConfig = {
              due: { color: colors.error[500], bg: colors.error[50], label: 'مطلوب الآن', Icon: AlertCircle },
              upcoming: { color: colors.warning[500], bg: colors.warning[50], label: 'قريباً', Icon: Clock },
              ok: { color: colors.success[500], bg: colors.success[50], label: 'جيد', Icon: CheckCircle },
            };
            const cfg = statusConfig[status];

            return (
              <View style={styles.maintCard}>
                <View style={[styles.maintIconBox, { backgroundColor: cfg.bg }]}>
                  <Icon size={24} color={cfg.color} strokeWidth={2} />
                </View>
                <View style={styles.maintInfo}>
                  <Text style={styles.maintName}>{item.name}</Text>
                  <View style={styles.maintDetailsRow}>
                    <Text style={styles.maintDetail}>آخر تغيير: {item.last_replacement_odometer.toLocaleString('en-US')} كم</Text>
                    <Text style={styles.maintDetail}>الفاصل: {item.interval_km.toLocaleString('en-US')} كم</Text>
                  </View>
                  <View style={styles.maintProgressRow}>
                    <View style={styles.maintProgressBar}>
                      <View
                        style={[
                          styles.maintProgressFill,
                          {
                            width: `${Math.max(0, Math.min(100, ((selectedCar?.odometer ?? 0 - item.last_replacement_odometer) / item.interval_km) * 100))}%`,
                            backgroundColor: cfg.color,
                          },
                        ]}
                      />
                    </View>
                  </View>
                  <View style={styles.maintStatusRow}>
                    <View style={[styles.statusBadge, { backgroundColor: cfg.bg }]}>
                      <cfg.Icon size={14} color={cfg.color} strokeWidth={2} />
                      <Text style={[styles.statusText, { color: cfg.color }]}>{cfg.label}</Text>
                    </View>
                    <Text style={styles.remainingText}>
                      {remaining > 0
                        ? `يتبقى ${remaining.toLocaleString('en-US')} كم`
                        : `تجاوز ${Math.abs(remaining).toLocaleString('en-US')} كم`}
                    </Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.deleteItemButton}
                  onPress={() => handleDeleteItem(item)}
                >
                  <Trash2 size={16} color={colors.neutral[400]} strokeWidth={2} />
                </TouchableOpacity>
              </View>
            );
          }}
        />
      )}

      {/* Car Picker Modal */}
      <Modal visible={showCarPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { paddingBottom: insets.bottom + spacing.lg }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>اختر سيارة</Text>
              <TouchableOpacity onPress={() => setShowCarPicker(false)}>
                <X size={24} color={colors.text} strokeWidth={2} />
              </TouchableOpacity>
            </View>
            <ScrollView>
              {cars.map((car) => (
                <TouchableOpacity
                  key={car.id}
                  style={[
                    styles.carPickerItem,
                    selectedCarId === car.id && styles.carPickerItemSelected,
                  ]}
                  onPress={() => {
                    selectCar(car.id);
                    setShowCarPicker(false);
                  }}
                >
                  <Text style={styles.carPickerText}>
                    {car.nickname || `${car.make} ${car.model}`}
                  </Text>
                  <Text style={styles.carPickerSubtext}>
                    {car.make} • {car.model} • {car.year}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Add Maintenance Modal */}
      <AddMaintenanceModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={handleAddItem}
      />
    </View>
  );
}

function UpdateOdometerButton({ currentOdo, onUpdate }: { currentOdo: number; onUpdate: (n: number) => void }) {
  const [showModal, setShowModal] = useState(false);
  const [value, setValue] = useState(String(currentOdo));

  const handleSave = () => {
    const num = parseInt(value, 10);
    if (!isNaN(num) && num >= 0) {
      onUpdate(num);
      setShowModal(false);
    }
  };

  return (
    <>
      <TouchableOpacity style={styles.updateOdoButton} onPress={() => { setValue(String(currentOdo)); setShowModal(true); }}>
        <SettingsIcon size={16} color={colors.primary[600]} strokeWidth={2} />
        <Text style={styles.updateOdoText}>تحديث</Text>
      </TouchableOpacity>
      <Modal visible={showModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.smallModal}>
            <Text style={styles.modalTitle}>تحديث قراءة العداد</Text>
            <TextInput
              style={styles.modalInput}
              value={value}
              onChangeText={setValue}
              keyboardType="numeric"
              textAlign="center"
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowModal(false)}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmButton} onPress={handleSave}>
                <Text style={styles.confirmButtonText}>حفظ</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

function AddMaintenanceModal({
  visible,
  onClose,
  onAdd,
}: {
  visible: boolean;
  onClose: () => void;
  onAdd: (item: Omit<MaintenanceItem, 'id' | 'car_id' | 'created_at' | 'updated_at'>) => void;
}) {
  const [category, setCategory] = useState<MaintenanceCategory>('engine_oil');
  const [name, setName] = useState('');
  const [lastOdo, setLastOdo] = useState('');
  const [interval, setInterval] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSave = () => {
    const lastOdoNum = parseInt(lastOdo, 10);
    const intervalNum = parseInt(interval, 10);
    if (isNaN(lastOdoNum) || lastOdoNum < 0) {
      setError('قراءة العداد عند آخر تغيير غير صحيحة');
      return;
    }
    if (isNaN(intervalNum) || intervalNum <= 0) {
      setError('فاصل الصيانة يجب أن يكون رقماً موجباً');
      return;
    }
    const catLabel = MAINTENANCE_CATEGORIES.find(c => c.key === category)?.label || 'صيانة';
    onAdd({
      name: name.trim() || catLabel,
      category,
      last_replacement_odometer: lastOdoNum,
      interval_km: intervalNum,
    });
    setCategory('engine_oil');
    setName('');
    setLastOdo('');
    setInterval('');
    setError(null);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { paddingBottom: 30 }]}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>إضافة عنصر صيانة</Text>
            <TouchableOpacity onPress={onClose}>
              <X size={24} color={colors.text} strokeWidth={2} />
            </TouchableOpacity>
          </View>
          <ScrollView keyboardShouldPersistTaps="handled">
            {error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}
            <Text style={styles.label}>النوع</Text>
            <View style={styles.categoryGrid}>
              {MAINTENANCE_CATEGORIES.map((cat) => {
                const Icon = CATEGORY_ICONS[cat.key] || Wrench;
                return (
                  <TouchableOpacity
                    key={cat.key}
                    style={[
                      styles.categoryItem,
                      category === cat.key && styles.categoryItemSelected,
                    ]}
                    onPress={() => setCategory(cat.key)}
                  >
                    <Icon
                      size={20}
                      color={category === cat.key ? colors.white : colors.primary[600]}
                      strokeWidth={2}
                    />
                    <Text
                      style={[
                        styles.categoryItemText,
                        category === cat.key && styles.categoryItemTextSelected,
                      ]}
                    >
                      {cat.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {category === 'custom' && (
              <>
                <Text style={styles.label}>اسم القطعة</Text>
                <TextInput
                  style={styles.input}
                  value={name}
                  onChangeText={setName}
                  placeholder="مثال: بطارية"
                  placeholderTextColor={colors.neutral[400]}
                  textAlign="right"
                />
              </>
            )}

            <Text style={styles.label}>قراءة العداد عند آخر تغيير (كم)</Text>
            <TextInput
              style={styles.input}
              value={lastOdo}
              onChangeText={setLastOdo}
              placeholder="مثال: 40000"
              placeholderTextColor={colors.neutral[400]}
              keyboardType="numeric"
              textAlign="right"
            />

            <Text style={styles.label}>فاصل الصيانة (كم)</Text>
            <TextInput
              style={styles.input}
              value={interval}
              onChangeText={setInterval}
              placeholder="مثال: 10000"
              placeholderTextColor={colors.neutral[400]}
              keyboardType="numeric"
              textAlign="right"
            />

            <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
              <Text style={styles.saveButtonText}>إضافة</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xxxl,
    color: colors.text,
  },
  carSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary[50],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    gap: spacing.xs,
    maxWidth: 200,
  },
  carSelectorText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.sm,
    color: colors.primary[700],
  },
  odometerCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.surface,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
    padding: spacing.md,
    borderRadius: radius.lg,
  },
  odometerLeft: {
    flex: 1,
  },
  odometerLabel: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.xs,
    color: colors.textSecondary,
  },
  odometerValue: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xxl,
    color: colors.text,
    marginTop: 2,
  },
  updateOdoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary[50],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    gap: spacing.xs,
  },
  updateOdoText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.sm,
    color: colors.primary[700],
  },
  list: {
    paddingHorizontal: spacing.lg,
  },
  addItemButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary[50],
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    marginBottom: spacing.md,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.primary[200],
    borderStyle: 'dashed',
  },
  addItemText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.primary[700],
  },
  maintCard: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  maintIconBox: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  maintInfo: {
    flex: 1,
    marginRight: spacing.md,
    marginLeft: spacing.sm,
  },
  maintName: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.lg,
    color: colors.text,
  },
  maintDetailsRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.xs,
    flexWrap: 'wrap',
  },
  maintDetail: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.xs,
    color: colors.textSecondary,
  },
  maintProgressRow: {
    marginTop: spacing.sm,
  },
  maintProgressBar: {
    height: 6,
    backgroundColor: colors.neutral[200],
    borderRadius: radius.round,
    overflow: 'hidden',
  },
  maintProgressFill: {
    height: '100%',
    borderRadius: radius.round,
  },
  maintStatusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
    gap: 4,
  },
  statusText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.xs,
  },
  remainingText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.xs,
    color: colors.textSecondary,
  },
  deleteItemButton: {
    padding: spacing.xs,
    alignSelf: 'flex-start',
    marginTop: spacing.xs,
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: spacing.xxl * 2,
  },
  emptyTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xl,
    color: colors.text,
    marginTop: spacing.md,
  },
  emptySubtitle: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.md,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.lg,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  modalTitle: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.xl,
    color: colors.text,
  },
  smallModal: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.lg,
    width: '85%',
    maxWidth: 350,
    alignSelf: 'center',
    marginTop: 'auto',
    marginBottom: 'auto',
  },
  modalInput: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.lg,
    backgroundColor: colors.background,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    marginVertical: spacing.md,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.neutral[200],
    alignItems: 'center',
  },
  cancelButtonText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.textSecondary,
  },
  confirmButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.primary[600],
    alignItems: 'center',
  },
  confirmButtonText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.white,
  },
  carPickerItem: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.xs,
    backgroundColor: colors.background,
  },
  carPickerItemSelected: {
    backgroundColor: colors.primary[50],
    borderWidth: 2,
    borderColor: colors.primary[400],
  },
  carPickerText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.md,
    color: colors.text,
  },
  carPickerSubtext: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  errorBox: {
    backgroundColor: colors.error[50],
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.error[500],
  },
  errorText: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.sm,
    color: colors.error[600],
    textAlign: 'center',
  },
  label: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.sm,
    color: colors.text,
    marginBottom: spacing.xs,
    textAlign: 'right',
    marginTop: spacing.sm,
  },
  input: {
    fontFamily: fontWeight.regular,
    fontSize: fontSize.md,
    backgroundColor: colors.background,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    textAlign: 'right',
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: colors.primary[50],
    gap: spacing.xs,
  },
  categoryItemSelected: {
    backgroundColor: colors.primary[600],
  },
  categoryItemText: {
    fontFamily: fontWeight.medium,
    fontSize: fontSize.sm,
    color: colors.primary[700],
  },
  categoryItemTextSelected: {
    color: colors.white,
  },
  saveButton: {
    backgroundColor: colors.primary[600],
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  saveButtonText: {
    fontFamily: fontWeight.bold,
    fontSize: fontSize.lg,
    color: colors.white,
  },
});
