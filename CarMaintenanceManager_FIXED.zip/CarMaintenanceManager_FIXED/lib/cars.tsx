import { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { Car } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

interface CarContextType {
  cars: Car[];
  selectedCarId: string | null;
  selectedCar: Car | null;
  loading: boolean;
  error: string | null;
  fetchCars: () => Promise<void>;
  selectCar: (id: string) => void;
  addCar: (data: Omit<Car, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<{ error: string | null }>;
  updateCar: (id: string, data: Partial<Car>) => Promise<{ error: string | null }>;
  deleteCar: (id: string) => Promise<{ error: string | null }>;
}

const CarContext = createContext<CarContextType | undefined>(undefined);

export function CarProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [cars, setCars] = useState<Car[]>([]);
  const [selectedCarId, setSelectedCarId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCars = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('cars')
      .select('*')
      .order('created_at', { ascending: true });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    setCars(data || []);
    if (data && data.length > 0 && !selectedCarId) {
      setSelectedCarId(data[0].id);
    }
    if (data && data.length > 0 && selectedCarId && !data.find(c => c.id === selectedCarId)) {
      setSelectedCarId(data[0].id);
    }
    if (!data || data.length === 0) {
      setSelectedCarId(null);
    }
  }, [user, selectedCarId]);

  const selectCar = (id: string) => setSelectedCarId(id);

  const addCar = async (data: Omit<Car, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    const { data: newCar, error } = await supabase
      .from('cars')
      .insert(data)
      .select()
      .single();
    if (error) return { error: error.message };
    if (newCar) {
      setCars(prev => [...prev, newCar]);
      if (!selectedCarId) setSelectedCarId(newCar.id);
    }
    return { error: null };
  };

  const updateCar = async (id: string, data: Partial<Car>) => {
    const { data: updated, error } = await supabase
      .from('cars')
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) return { error: error.message };
    if (updated) {
      setCars(prev => prev.map(c => (c.id === id ? updated : c)));
    }
    return { error: null };
  };

  const deleteCar = async (id: string) => {
    const { error } = await supabase.from('cars').delete().eq('id', id);
    if (error) return { error: error.message };
    setCars(prev => prev.filter(c => c.id !== id));
    if (selectedCarId === id) {
      setSelectedCarId(cars.find(c => c.id !== id)?.id ?? null);
    }
    return { error: null };
  };

  const selectedCar = cars.find(c => c.id === selectedCarId) ?? null;

  return (
    <CarContext.Provider
      value={{
        cars,
        selectedCarId,
        selectedCar,
        loading,
        error,
        fetchCars,
        selectCar,
        addCar,
        updateCar,
        deleteCar,
      }}
    >
      {children}
    </CarContext.Provider>
  );
}

export function useCars() {
  const ctx = useContext(CarContext);
  if (!ctx) throw new Error('useCars must be used within CarProvider');
  return ctx;
}
