import * as Notifications from 'expo-notifications';
import { Car, MaintenanceItem, getRemainingKm, getMaintenanceStatus } from '@/lib/types';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function checkMaintenanceNotifications(
  car: Car,
  items: MaintenanceItem[]
): Promise<void> {
  for (const item of items) {
    const status = getMaintenanceStatus(item, car.odometer);
    if (status === 'due' || status === 'upcoming') {
      const remaining = getRemainingKm(item, car.odometer);
      const carName = car.nickname || `${car.make} ${car.model}`;
      const title = status === 'due' ? 'صيانة مطلوبة الآن' : 'صيانة قريبة';
      const body = `${item.name} - ${carName}: ${
        remaining > 0
          ? `يتبقى ${remaining.toLocaleString('en-US')} كم`
          : `تجاوز ${Math.abs(remaining).toLocaleString('en-US')} كم`
      }`;

      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          sound: true,
          data: { itemId: item.id, carId: car.id },
        },
        trigger: null,
      });
    }
  }
}

export async function sendTestNotification(): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'إشعار تجريبي',
      body: 'الإشعارات تعمل بشكل صحيح',
      sound: true,
    },
    trigger: null,
  });
}
