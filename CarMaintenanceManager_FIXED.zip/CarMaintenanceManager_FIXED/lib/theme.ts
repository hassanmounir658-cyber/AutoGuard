export const colors = {
  primary: {
    50: '#e8f5e9',
    100: '#c8e6c9',
    200: '#a5d6a7',
    300: '#81c784',
    400: '#66bb6a',
    500: '#43a047',
    600: '#388e3c',
    700: '#2e7d32',
    800: '#1b5e20',
    900: '#0d3f12',
  },
  accent: {
    50: '#fff8e1',
    100: '#ffecb3',
    200: '#ffe082',
    300: '#ffd54f',
    400: '#ffca28',
    500: '#ffb300',
    600: '#ff8f00',
    700: '#ff6f00',
  800: '#e65100',
    900: '#bf360c',
  },
  neutral: {
    50: '#fafafa',
    100: '#f5f5f5',
    200: '#e0e0e0',
    300: '#bdbdbd',
    400: '#9e9e9e',
    500: '#757575',
    600: '#616161',
    700: '#424242',
    800: '#212121',
    900: '#1a1a1a',
  },
  success: {
    500: '#43a047',
    600: '#388e3c',
    50: '#e8f5e9',
  },
  warning: {
    500: '#ff9800',
    600: '#f57c00',
    50: '#fff3e0',
  },
  error: {
    500: '#e53935',
    600: '#c62828',
    50: '#ffebee',
  },
  white: '#ffffff',
  black: '#000000',
  background: '#f5f5f5',
  surface: '#ffffff',
  text: '#212121',
  textSecondary: '#757575',
  border: '#e0e0e0',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  round: 999,
};

export const fontSize = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const fontWeight = {
  regular: 'Cairo-Regular',
  medium: 'Cairo-Medium',
  bold: 'Cairo-Bold',
};
