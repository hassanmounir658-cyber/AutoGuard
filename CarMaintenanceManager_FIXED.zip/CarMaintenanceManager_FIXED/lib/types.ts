export type MaintenanceCategory =
  | 'engine_oil'
  | 'transmission_oil'
  | 'oil_filter'
  | 'air_filter'
  | 'cabin_filter'
  | 'spark_plugs'
  | 'tires'
  | 'custom';

export interface Car {
  id: string;
  user_id: string;
  make: string;
  model: string;
  year: number;
  odometer: number;
  nickname: string | null;
  created_at: string;
  updated_at: string;
}

export interface MaintenanceItem {
  id: string;
  car_id: string;
  name: string;
  category: MaintenanceCategory;
  last_replacement_odometer: number;
  interval_km: number;
  created_at: string;
  updated_at: string;
}

export interface CarWithMaintenance extends Car {
  maintenance_items: MaintenanceItem[];
}

export const MAINTENANCE_CATEGORIES: { key: MaintenanceCategory; label: string; icon: string }[] = [
  { key: 'engine_oil', label: 'زيت المحرك', icon: 'oil' },
  { key: 'transmission_oil', label: 'زيت ناقل الحركة', icon: 'transmission' },
  { key: 'oil_filter', label: 'فلتر الزيت', icon: 'filter' },
  { key: 'air_filter', label: 'فلتر الهواء', icon: 'wind' },
  { key: 'cabin_filter', label: 'فلتر المقصورة', icon: 'cabin' },
  { key: 'spark_plugs', label: 'البوجيهات', icon: 'spark' },
  { key: 'tires', label: 'الإطارات', icon: 'tire' },
  { key: 'custom', label: 'قطعة مخصصة', icon: 'custom' },
];

export function getNextMaintenanceOdometer(item: MaintenanceItem): number {
  return item.last_replacement_odometer + item.interval_km;
}

export function getRemainingKm(item: MaintenanceItem, currentOdometer: number): number {
  return getNextMaintenanceOdometer(item) - currentOdometer;
}

export type MaintenanceStatus = 'due' | 'upcoming' | 'ok';

export function getMaintenanceStatus(item: MaintenanceItem, currentOdometer: number): MaintenanceStatus {
  const remaining = getRemainingKm(item, currentOdometer);
  if (remaining <= 0) return 'due';
  if (remaining <= item.interval_km * 0.1) return 'upcoming';
  return 'ok';
}
