/*
# Create cars and maintenance_items tables

## Overview
This migration creates the core data model for a car maintenance management app.
Each authenticated user owns their cars and maintenance records. Data is isolated per user via RLS.

## New Tables

### cars
- `id` (uuid, primary key)
- `user_id` (uuid, references auth.users, owner of the car)
- `make` (text, e.g. "Toyota")
- `model` (text, e.g. "Camry")
- `year` (integer, e.g. 2020)
- `odometer` (integer, current odometer reading in km)
- `nickname` (text, optional friendly name)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### maintenance_items
- `id` (uuid, primary key)
- `car_id` (uuid, references cars, cascade delete)
- `name` (text, e.g. "Engine Oil", "Tires", or custom part name)
- `category` (text, one of: engine_oil, transmission_oil, oil_filter, air_filter, cabin_filter, spark_plugs, tires, custom)
- `last_replacement_odometer` (integer, km reading at last replacement)
- `interval_km` (integer, replacement interval in kilometers)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## Security
- RLS enabled on both tables.
- cars: owner-scoped CRUD via auth.uid() = user_id
- maintenance_items: scoped through parent car ownership check
- user_id on cars defaults to auth.uid() so inserts omitting it still work
*/

CREATE TABLE IF NOT EXISTS cars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  make text NOT NULL,
  model text NOT NULL,
  year integer NOT NULL,
  odometer integer NOT NULL DEFAULT 0,
  nickname text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cars ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_cars" ON cars;
CREATE POLICY "select_own_cars" ON cars FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_cars" ON cars;
CREATE POLICY "insert_own_cars" ON cars FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_cars" ON cars;
CREATE POLICY "update_own_cars" ON cars FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_cars" ON cars;
CREATE POLICY "delete_own_cars" ON cars FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS maintenance_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'custom',
  last_replacement_odometer integer NOT NULL DEFAULT 0,
  interval_km integer NOT NULL DEFAULT 10000,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE maintenance_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_maintenance" ON maintenance_items;
CREATE POLICY "select_own_maintenance" ON maintenance_items FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM cars WHERE cars.id = maintenance_items.car_id AND cars.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_maintenance" ON maintenance_items;
CREATE POLICY "insert_own_maintenance" ON maintenance_items FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM cars WHERE cars.id = maintenance_items.car_id AND cars.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_maintenance" ON maintenance_items;
CREATE POLICY "update_own_maintenance" ON maintenance_items FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM cars WHERE cars.id = maintenance_items.car_id AND cars.user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM cars WHERE cars.id = maintenance_items.car_id AND cars.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_maintenance" ON maintenance_items;
CREATE POLICY "delete_own_maintenance" ON maintenance_items FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM cars WHERE cars.id = maintenance_items.car_id AND cars.user_id = auth.uid())
  );

CREATE INDEX IF NOT EXISTS idx_cars_user_id ON cars(user_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_car_id ON maintenance_items(car_id);
